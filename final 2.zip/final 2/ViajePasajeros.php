<?php

include_once 'BaseDatos.php';

class ViajePasajeros {
    private $IDviaje;
    private $IDpasajero;
    private $destinoViaje;
    private $IDempleado;
    private $mensaje;

    public function __construct(
        $IDviaje = 0,
        $IDpasajero = "", 
        $destinoViaje = "", 
        $IDempleado = 0
        ) {
        $this->IDviaje = $IDviaje;
        $this->IDpasajero = $IDpasajero;
        $this->destinoViaje = $destinoViaje;
        $this->IDempleado = $IDempleado;
        $this->mensaje = "";
    }

    public function cargar($IDviaje, $IDpasajero, $destinoViaje, $IDempleado) {
        $this->IDviaje = $IDviaje;
        $this->IDpasajero = $IDpasajero;
        $this->destinoViaje = $destinoViaje;
        $this->IDempleado = $IDempleado;
    }

    public function insertarViajePasajeros() {
        $base = new BaseDatos();
        $resp = false;
        $sql = "INSERT INTO ViajePasajeros (IDviaje, IDpasajero, destinoViaje, IDempleado) VALUES (
            " . intval($this->IDviaje) . ",
            '" . $this->IDpasajero . "',
            '" . $this->destinoViaje . "',
            " . intval($this->IDempleado) . "
        )";
        if ($base->IniciarBase()) {
            if ($base->EjecutarBase($sql)) {
                $resp = true;
            } else {
                $this->mensaje = $base->getERROR();
            }
        } else {
            $this->mensaje = $base->getERROR();
        }
        return $resp;
    }

    public function listarViajePasajeros($condicion = "") {
        $arreglo = null;
        $base = new BaseDatos();
        $sql = "SELECT * FROM ViajePasajeros";
        if ($condicion != "") {
            $sql .= " WHERE " . $condicion;
        }
        if ($base->IniciarBase()) {
            if ($base->EjecutarBase($sql)) {
                $arreglo = array();
                while ($row = $base->Registro()) {
                    $obj = new ViajePasajeros();
                    $obj->cargar($row['IDviaje'], $row['IDpasajero'], $row['destinoViaje'], $row['IDempleado']);
                    array_push($arreglo, $obj);
                }
            } else {
                $this->mensaje = $base->getERROR();
            }
        } else {
            $this->mensaje = $base->getERROR();
        }
        return $arreglo;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function __toString() {
        return "Viaje: " . $this->IDviaje . ", Pasajero: " . $this->IDpasajero . ", Destino: " . $this->destinoViaje . ", Responsable: " . $this->IDempleado;
    }
}